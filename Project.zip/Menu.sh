#!/bin/bash
menu()
{
	running= true;
	while $running; do
		echo 
		echo 
		echo $'This is your current directory\n'$(ls)
		echo 
		echo "Press 1 to change repository"
		echo "Press 2 to create a new repository"
		echo "Press 3 to add a file to a repository"
		echo "Press 4 to view the log file"
		echo "Press 5 to edit a file" 
		echo "Press 6 to zip a repository" 
		echo "Press 7 to go back a repository" 
		echo "Press 8 to remove a file" 
		read -p $'Press 0 if you would like to EXIT the program\n' value
		
		if [ $value -eq 1 ]; then
			changeRepo
			
		elif [ $value -eq 2 ]; then
			createRepo
			
		elif [ $value -eq 3 ]; then
			addFile
			
		elif [ $value -eq 4 ]; then
			viewLog
		
		elif [ $value -eq 5 ]; then
			editFile
		
		elif [ $value -eq 6 ]; then
			zipFile
		
		elif [ $value -eq 7 ]; then
			cd ..
			
		elif [ $value -eq 8 ]; then
			removeFile
			
		elif [ $value -eq 0 ]; then
			running= false
			break	
		fi
		
	done
}

createRepo()
{
	read -p "What name would you like to call this repository: " vName
	mkdir "$vName"
	read -p "Would you like to add add a comment to the log file y/n: " ans
	if [ $ans "y" ]; then
		read -p "What is your comment: " comment
		echo "A repository '$vName' was created		" $(date) "	" $(whoami) "		" $comment>> /home/vboxuser/Efiles/Project1/LogFile.txt
		echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
	else
		echo "A repository '$vName' was created		" $(date) "	" $(whoami) >> /home/vboxuser/Efiles/Project1/LogFile.txt
		echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
	fi
}

addFile()
{
	read -p "What do you want to call this file: " vFile
	echo "These are the available repositories for your file"
	echo */
	read -p "What repository would you like to add this file to: " rep
	if [ -d "$rep" ]; then
		cd $rep
		echo > "$vFile".txt
		cd ..
		read -p "Would you like to add add a comment to the log file y/n: " ans
		if [ $ans "y" ]; then
			read -p "What is your comment: " comment
			echo "A file '$vFile' has been created and saved into '$rep'		" $(date) "	" $(whoami)  "		" $comment >> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
		else
			echo "A file '$vFile' has been created and saved into '$rep'		" $(date) "	" $(whoami) >> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
		fi	
	else
		read -p "This repository does not exist would you like to create one y/n: " ans
		if [ $ans "y" ]; then
			createRepo
		elif [ $ans = "n" ]; then
			break
		else
			echo "That was not one of the answeres"
		fi
	fi
}

viewLog()
{
	cat LogFile.txt
}
editFile()
{
	ls
	read -p "Is the file you would like to edit in this repository y/n: " anss
	if [ $ans "y" ]; then
		find -type f
		read -p "What is the name of the file: " file
		filewithtext=$file.txt
		echo "$filewithtext"
		realpath="$(realpath "$filewithtext")"
		lockfiles="$realpath.lock"
		if [ -e "$lockfiles" ];then
			echo "already locked by another user"
		else
			touch "$lockfiles"
			nano $file
			rm "$lockfiles"
		fi	
		cd ..
		read -p "Would you like to add add a comment to the log file y/n: " ans
		if [ $ans "y" ]; then
			read -p "What is your comment: " comment
			echo "A file '$vFile' has been edited and saved in '$rep'		" $(date) "	" $(whoami)"		" $comment >> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
			
		else	
			echo "A file '$vFile' has been edited and saved in '$rep'		" $(date) "	" $(whoami) >> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
		fi
	elif [ $ans = "n" ]; then
		echo */
		read -p "What is the name of the directory: " dir
		cd dir
		find -type f
		read -p "What is the name of the file: " file
		
		filewithtext=$file.txt
		echo "$filewithtext"
		realpath="$(realpath "$filewithtext")"
		lockfiles="$realpath.lock"
		if [ -e "$lockfiles" ];then
			echo "already locked by another user"
		else
			touch "$lockfiles"
			nano $file
			rm "$lockfiles"
		fi
		cd ..
		read -p "Would you like to add add a comment to the log file y/n: " ans
		if [ $ans "y" ]; then
			read -p "What is your comment: " comment
			echo "A file '$vFile' has been edited and saved in '$rep'		" $(date) "	" $(whoami)"		" $comment >> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
			
		else	
			echo "A file '$vFile' has been edited and saved in '$rep'		" $(date) "	" $(whoami) >> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
		fi
	else
		echo "That was not one of the answeres"
	fi		
}

zipFile()
{
	echo */ 
	read -p "Which repository would you like to zip: " zDir
	read -p "What would you like to call your zip folder: " zFolder
	zip -r zFolder zDir
	read -p "Would you like to add add a comment to the log file y/n: " ans
	if [ $ans "y" ]; then
		read -p "What is your comment: " comment
		echo "A folder '$vDir' has been ziped into '$zFolder'		" $(date) "	" $(whoami) "		" $comment >> /home/vboxuser/Efiles/Project1/LogFile.txt
		echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
	else
		echo "A folder '$vDir' has been ziped into '$zFolder'		" $(date) "	" $(whoami)>> /home/vboxuser/Efiles/Project1/LogFile.txt
		echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
	fi
}

changeRepo()
{
	echo */
	read -p "Which repository woud you like to see: " nRepo
	cd $nRepo
}

removeFile()
{
	ls
	read -p "Is the file you would like to delete in this repository y/n: " ans
	if [ $ans "y" ]; then
		find -type f
		read -p "What would you like to remove " file
		rm $file
		read -p "Would you like to add add a comment to the log file y/n: " ans
		if [ $ans "y" ]; then
			read -p "What is your comment: " comment
			echo "A file was deleted $file'		" $(date) "	" $(whoami) "		" $comment >> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
		else
			echo "A file was deleted $file'		" $(date) "	" $(whoami)>> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
		fi
	elif [ $ans "n" ]; then
		echo */
		read -p "What is the name of the directory: " dir
		cd dir
		find -type f
		read -p "What is the name of the file: " file
		rm $file
		read -p "Would you like to add add a comment to the log file y/n: " ans
		if [ $ans "y" ]; then
			read -p "What is your comment: " comment
			echo "A file was deleted $file'		" $(date) "	" $(whoami) "		" $comment >> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
		else
			echo "A file was deleted $file''		" $(date) "	" $(whoami)>> /home/vboxuser/Efiles/Project1/LogFile.txt
			echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
		fi
	else
		echo that was not an answers
	fi
}

compileFile()
{
	ls
	read -p "Is the file you would like to compile in this repository y/n: " ans
	if [ $ans "y" ]; then
		ls
		read -p "What would you like to compile " cFile
		read -p "What would you like to call the executable file " eFile
		gcc -o "$eFile" "$cFile"
		if [ $? -eq 0 ]; then
			echo successfull compilation. Running the program
			./"$eFile"
			read -p "Would you like to add add a comment to the log file y/n: " ans
			if [ $ans "y" ]; then
				read -p "What is your comment: " comment
				echo "A file was compiled and ran $eFile'		" $(date) "	" $(whoami) "		" $comment >> /home/vboxuser/Efiles/Project1/LogFile.txt
				echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
			else
				echo "A file '$eFile' has been created and ran'		" $(date) "	" $(whoami)>> /home/vboxuser/Efiles/Project1/LogFile.txt
				echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
			fi
		else
			echo Compilation failed
		fi
		
	elif [ $ans "n" ]; then		
		echo */
		read -p "What is the name of the directory: " dir
		cd dir
		ls
		read -p "What would you like to compile " cFile
		read -p "What would you like to call the executable file " eFile
		if [ $? -eq 0 ]; then
			echo successfull compilation. Running the program
			./"$eFile"
			read -p "Would you like to add add a comment to the log file y/n: " ans
			if [ $ans "y" ]; then
				read -p "What is your comment: " comment
				echo "A file was compiled and ran $eFile'		" $(date) "	" $(whoami) "		" $comment >> /home/vboxuser/Efiles/Project1/LogFile.txt
				echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
			else
				echo "A file '$eFile' has been created and ran'		" $(date) "	" $(whoami)>> /home/vboxuser/Efiles/Project1/LogFile.txt
				echo >> /home/vboxuser/Efiles/Project1/LogFile.txt
			fi
		else
			echo Compilation failed
		fi
	else
		echo that was not one of the answers
	fi
}


menu
